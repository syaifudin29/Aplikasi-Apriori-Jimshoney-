<?php

namespace App\Controllers;

class Laporan extends BaseController
{
    public function index()
    {
    	if (session()->has('id_user') == false) {
            return redirect()->to('/login'); 
        }
        $hasil = $this->hasilModel->findAll();
    	$data = ['menu' => 'laporan', 'hasil' => $hasil];
        return view('laporan', $data);
    }

    public function delete($id){
        $this->hasilModel->delete($id);
       	return redirect()->to('/laporan');
    }

    public function view($id_hasil){

        $itm1 = $this->itemSatu->findAll();
        foreach ($itm1 as $key) {
            $this->itemSatu->where('id', $key['id'])->delete();
        }
            
        $itm2 = $this->itemDua->findAll();
        foreach ($itm2 as $key) {
            $this->itemDua->where('id', $key['id'])->delete();
        }

        $aso = $this->assoSatu->findAll();
        foreach ($aso as $key) {
            $this->assoSatu->where('id', $key['id'])->delete();
        }
        $aso2 = $this->assoDua->findAll();
        foreach ($aso2 as $key) {
            $this->assoDua->where('id', $key['id'])->delete();
        }
        
        $laporan_view = $this->hasilModel->find($id_hasil);
    	$suport = $laporan_view['support'];
    	$cofidens = $laporan_view['confidence'];
    	$awal = $laporan_view['tanggal_awal'];
    	$akhir = $laporan_view['tanggal_akhir'];

        // $hasil_laporan = $this->hasilModel->where('tanggal_awal', $awal)->where('tanggal_akhir', $akhir)->where('confidence', $cofidens)->where('support', $suport)->findAll();
        // dd($cofidens);
        // if(count($hasil_laporan) != 0){
        //     session()->setFlashdata('info', 'Sudah pernah diproses. Lihat di laporan');
        //     return redirect()->to('/apriori');
        // }

        //delete data
        $analdata = $this->analisaModel->findAll();
        foreach ($analdata as $key) {
            $this->analisaModel->delete($key['id']);
        }

    	//menampilkan data item set 1
    	$produk = $this->produkModel->findAll();

    	$where = "tanggal BETWEEN '".$awal."' AND '".$akhir."'";
    	$penjualan = $this->penjualanModel->where($where)->where('status', '1')->findAll();
    	
        //cek data kosong
        if(count($penjualan) == 0){
            session()->setFlashdata('info', 'Data kosong.');
            return redirect()->to('/apriori');
        }
    	//menampilkan data sesuai tanggal
    	$transaksi = $this->penjualanModel->select('distinct(id_penjualan) as id_penjualan')->where($where)->findAll();
    	
    	//hitung jumlah transaksi
    	$penj = $this->penjualanModel->select('distinct(id_penjualan)')->findAll();
        
    	$jmlpenj = count($penj);

    	$no=1;
         $data['item1'] = [];
    	foreach ($produk as $key) {
    		$total=0;
    		foreach ($penjualan as $keys) {
    			if ($key['id_produk'] == $keys['id_produk']) {
    				$total=$total+1;
    			}
    		}

    			// $data['item1'][$no++] = ['id_produk' => $key['id_produk'],'nama' => $key['nama'], 'total' => ($total/$jmlpenj)];
       //          $hasil = ['kelompok' => 1, 'id_produk' => $key['id_produk'], 'jumlah' => $total, 'itemset' => 1];
       //          $this->analisaModel->save($hasil);
             $this->itemSatu->insert(['id_produk' => $key['id_produk'], 'jumlah' => $total, 'support' => ($total/$jmlpenj)]);
            if (($total/$jmlpenj) >= $suport) {
                $data['item1'][$no++] = ['id_produk' => $key['id_produk'],'nama' => $key['nama'], 'total' => ($total/$jmlpenj)];
                  $this->itemSatu->set('lolos', '1')->where('id_produk', $key['id_produk'])->update();
               
                // $hasil[$no++] = ['kelompok' => 1, 'id_produk' => $key['id_produk'], 'jumlah' => ];
                // $this->analisaModel->save()
            }else{
                 $this->itemSatu->set('lolos', '0')->where('id_produk', $key['id_produk'])->update();
            }
            
    	}

        //end item set 1

        //start item set 2
        
        $data['item2']=[];
        $no=1;
        $kode=1;
        
        if(count($data['item1']) == 0){
             session()->setFlashdata('info', 'Produk tidak ada yang lolos itemset 1.');
            // dd();
            return redirect()->to('/apriori');
        }
        $jumset1 = count($data['item1']);
         for($i=1; $i<=$jumset1; $i++){
           for($j=1; $j<=$jumset1-$i; $j++){
             $data['item2'][$no++] = ['kode' => $kode++, 'id_produk_1' => $data['item1'][$i]['id_produk'], 'id_produk_2' => $data['item1'][$j + $i]['id_produk']];
            }
         }
      

        //menghitung item set 2
        $total=0;
        $no=1;

        foreach ($data['item2'] as $keyp) {
            foreach ($penj as $key) {
                $dat1 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $keyp['id_produk_1'])->findAll();
                if (!empty($dat1)) {
                     $dat2 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $keyp['id_produk_2'])->findAll();
                     if (!empty($dat2)) {
                         $total=$total+1;
                     }
                }
            }
                $item2[$no++] = ['kode' => $keyp['kode'], 'total' => ($total/$jmlpenj), 'jml' => $total];
                //kene
                $total=0;
        }
        
        $no=1;
        foreach ($data['item2'] as $key) {
            foreach ($item2 as $keys) {
                if ($keys['kode'] == $key['kode']) {
                    $data['item2_hasil'][$no++] = ['kode' => $key['kode'], 'id_produk_1' => $key['id_produk_1'], 'id_produk_2' => $key['id_produk_2'], 'total' => $keys['total']];
                    $this->itemDua->insert(['id_produk_1' => $key['id_produk_1'], 'id_produk_2' => $key['id_produk_2'], 'jumlah' => $keys['jml'], 'support' => $keys['total']]);
                }
            }
        }


        //item set 3
        //cek data yang masuk itemset 3
        $no=0;
        $data['item2_lolos'] = [];
        foreach ($data['item2_hasil'] as $key) {
            if ($key['total'] >= $suport) {
                  $data['item2_lolos'][$no++] = ['kode' => $key['kode'], 'id_produk_1' => $key['id_produk_1'], 'id_produk_2' => $key['id_produk_2'], 'total' => $key['total']];
            }
        }
      
        //asosiasi item set 2
        $nok = 1;
        $asosi = [];
         if(count($data['item2_lolos']) == 0){
             session()->setFlashdata('info', 'Produk tidak ada yang lolos itemset 2.');
            // dd();
            return redirect()->to('/apriori');
        }
        foreach ($data['item2_lolos'] as $key) {
            $aso1 = $this->assoSatu->where('id_produk_2', $key['id_produk_2'])->where('id_produk_1', $key['id_produk_1'])->findAll();
            if(count($aso1) == 0){
             $this->assoSatu->insert(['id_produk_2' => $key['id_produk_2'], 'id_produk_1' => $key['id_produk_1']]);
            }
            $aso2 = $this->assoSatu->where('id_produk_2', $key['id_produk_1'])->where('id_produk_1', $key['id_produk_2'])->findAll();
            if(count($aso2) == 0){
             $this->assoSatu->insert(['id_produk_2' => $key['id_produk_1'], 'id_produk_1' => $key['id_produk_2']]);
            }
        }

        //menghitung assosiasi itemset 2
        $data_asso =  $this->assoSatu->findAll();
        $no=0;
        $data['asso_item2'] = [];
        foreach ($data_asso as $key ) {
            $asso1 =  $this->itemDua->where('id_produk_1', $key['id_produk_1'])->where('id_produk_2', $key['id_produk_2'])->findAll();
            if (count($asso1) != 0) {
                $item1 =  $this->itemSatu->where('id_produk', $key['id_produk_1'])->findAll();
                $data['asso_item2'][$no++] = ['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'AB' => $asso1[0]['jumlah'], 'A' => $item1[0]['jumlah'], 'cofidence' => ($asso1[0]['jumlah']/$item1[0]['jumlah'])];
            }
            
            $asso2 =  $this->itemDua->where('id_produk_1', $key['id_produk_2'])->where('id_produk_2', $key['id_produk_1'])->findAll();
            if (count($asso2) != 0) {
                $item1 =  $this->itemSatu->where('id_produk', $key['id_produk_1'])->findAll();
                $data['asso_item2'][$no++] = ['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'AB' => $asso2[0]['jumlah'], 'A' => $item1[0]['jumlah'], 'cofidence' => ($asso2[0]['jumlah']/$item1[0]['jumlah'])];
            }
        }

        //cek cofidense >= $cofeidence
        // dd( $data['asso_item2']);
        $no=0;
        $data['asso_item2_berhasil'] = [];
        foreach ($data['asso_item2'] as $key) {
            if ($key['cofidence'] >= $cofidens) {
                $item1 =  $this->itemDua->where('id_produk_1', $key['id_produk_1'])->where('id_produk_2', $key['id_produk_2'])->findAll();
                if(count($item1) == 0){
                    $item2 =  $this->itemDua->where('id_produk_1', $key['id_produk_2'])->where('id_produk_2', $key['id_produk_1'])->findAll();
                    $data['asso_item2_berhasil'][$no++] = ['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'support' => $item2[0]['support'], 'cofidence' => $key['cofidence'], 'total' => ($item2[0]['support']*$key['cofidence']) ];
                    $this->assoDua->insert(['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'support' => $item2[0]['support'], 'cofidence' => $key['cofidence'], 'total' => ($item2[0]['support']*$key['cofidence']) ]);
                }else{
                    $data['asso_item2_berhasil'][$no++] = ['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'support' => $item1[0]['support'], 'cofidence' => $key['cofidence'], 'total' => ($item1[0]['support']*$key['cofidence']) ];
                    $this->assoDua->insert(['id_produk_1' => $key['id_produk_1'],'id_produk_2' => $key['id_produk_2'], 'support' => $item1[0]['support'], 'cofidence' => $key['cofidence'], 'total' => ($item1[0]['support']*$key['cofidence']) ]);
                }
            }
        }
        //membuat variabel baru untuk nampung data produk yang lolos
        $no=0;
        foreach ($data['item2_lolos'] as $key) {
            $dat3[$no++]=$key['id_produk_1'];
        }

        foreach ($data['item2_lolos'] as $key) {
            $dat3[$no++]=$key['id_produk_2'];
        }

        $dat3 = array_unique($dat3);
        $no=0;
        foreach ($dat3 as $key) {
            $nilaidata3[$no++] = ['id_produk' => $key];
        }
        //end lolos

    
        //mendapatkan nilai produk 1, 2, 3 berbeda setelah lolos
        $data['item3']=[];
        $no=1;
        $kode=1;
        foreach ($nilaidata3 as $key) {

            foreach ($nilaidata3 as $keys) {

                foreach ($nilaidata3 as $keyu) {
                    
                    if ($keys['id_produk']!=$key['id_produk']) {

                        if ($keys['id_produk'] != $keyu['id_produk']) {
                            # code...
                            if ($key['id_produk'] != $keyu['id_produk']) {
                                # code...
                                if (empty($data['item3'])) {
                                        $data['item3'][$no] = ['kode' => $kode++,'id_produk_1' => $key['id_produk'], 'id_produk_2' => $keys['id_produk'], 'id_produk_3' => $keyu['id_produk']];
                                    }else{
                                    foreach ($data['item3'] as $keyp) {
                                        if ($keyp['id_produk_1'] == $keys['id_produk']) {
                                            if ($keyp['id_produk_2'] == $key['id_produk']) {
                                                if ($keyp['id_produk_3'] == $keyu['id_produk']) { }else{
                                                    $data['item3'][$no] = ['kode' => $kode++, 'id_produk_1' => $key['id_produk'], 'id_produk_2' => $keys['id_produk'], 'id_produk_3' => $keyu['id_produk']];
                                                }
                                            }
                                        }
                                        if ($keyp['id_produk_2'] == $keys['id_produk']) {
                                            if ($keyp['id_produk_1'] == $key['id_produk']) {
                                                if ($keyp['id_produk_3'] == $keyu['id_produk']) { }else{
                                                    $data['item3'][$no] = ['kode' => $kode++, 'id_produk_1' => $key['id_produk'], 'id_produk_2' => $keys['id_produk'], 'id_produk_3' => $keyu['id_produk']];
                                                }
                                            }
                                        }
                                        if ($keyp['id_produk_3'] == $keys['id_produk']) {
                                            if ($keyp['id_produk_2'] == $key['id_produk']) {
                                                if ($keyp['id_produk_1'] == $keyu['id_produk']) { }else{
                                                    $data['item3'][$no] = ['kode' => $kode++, 'id_produk_1' => $key['id_produk'], 'id_produk_2' => $keys['id_produk'], 'id_produk_3' => $keyu['id_produk']];
                                                }
                                            }
                                        }
                                    }
                                }
                                    $no++;
                            }
                        }{

                        }
                        
                    }
                }
                }
        }
        //end mendapatkan nilai produk 1,2,3

        // menghitung nilai items3


        // $total=0;
        // $no=1;

        // foreach ($data['item3'] as $keyp1) {
        //     foreach ($data['item3'] as $keyp2) {
        //         foreach ($data['item3'] as $keyp3) {
        //             foreach ($penj as $key) {
        //                 $data1 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $keyp1['id_produk_1'])->findAll();
        //             }
        //         }

        //     }
        // }
      
        $total=0;
        $no=0;
        foreach ($penj as $key) {
            foreach ($data['item3'] as $key1) {
                $dataset31 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $key1['id_produk_1'])->findAll();
                if(count($dataset31) != 0){
                    $dataset32 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $key1['id_produk_2'])->findAll();
                    if(count($dataset32) != 0){
                        $dataset33 = $this->penjualanModel->where($where)->where('id_penjualan', $key['id_penjualan'])->where('id_produk', $key1['id_produk_3'])->findAll();
                        if(count($dataset33) != 0){
                            $total++;
                        }
                    }
                }
            }
        }

        $data['item3_hasil'][0] = ['id_produk_1' => $key1['id_produk_1'],'id_produk_2' => $key1['id_produk_2'], 'id_produk_3' => $key1['id_produk_3'], 'jumlah' => $total/$jmlpenj, 'total' => $total ];
        if ($data['item3_hasil'][0]['jumlah'] >= $suport) {
            // echo "lanjut";
        }else{
            // echo "selesai";
        }
       
        $item1 = $this->itemSatu ->join('produk','produk.id_produk=itemset1.id_produk')->findAll();
        $item2 = $this->itemDua->findAll();
        $assoMax = $this->assoDua->select('id_produk_1,id_produk_2, support, cofidence, MAX(total) as total')->findAll();
        $produk = $this->produkModel->findAll();
        
    	$view = ['menu' => 'apriori',
                'data' => $data,
                'produk' => $produk,
                'item1' => $item1,
                'item2' => $item2,
                'assoMax'  => $assoMax,
                'bulan_awal' => $awal,
                'bulan_akhir'   => $akhir  
    			];

        return view('view_laporan', $view);
    }
}
