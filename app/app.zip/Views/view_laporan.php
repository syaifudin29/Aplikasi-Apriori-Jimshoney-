<?= $this->extend('template');
    $this->section('content');
?>
<div class="container-fluid">
        <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Itemset 1</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Produk</th>
                                            <th>Transaksi</th>
                                            <th>Support</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($item1 as $key ) {?>
                                         <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $key['nama']; ?></td>
                                            <td><?php echo $key['jumlah']; ?></td>
                                             <td><?php echo $key['support']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <h5 class="text-success"><b>Itemset 1 Lolos</b></h5>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Produk</th>
                                            <th>Support</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($data['item1'] as $key ) {?>
                                         <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $key['nama']; ?></td>
                                             <td><?php echo $key['total']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Itemset 2</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Produk 1</th>
                                            <th>Produk 2</th>
                                            <th>Transaksi</th>
                                            <th>Support</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($item2 as $key ) {?>
                                         <tr>
                                            <td><?php echo $no++; ?></td>
                                            <?php 
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                    ?>
                                                      <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                                 foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                    ?>
                                                      <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                            ?>
                                            <td><?php echo $key['jumlah']; ?></td>
                                            <td><?php echo $key['support']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <h5 class="text-success"><b>Itemset 2 Lolos</b></h5>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Produk 1</th>
                                            <th>Produk 2</th>
                                            <th>Support</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($data['item2_lolos'] as $key ) {?>
                                         <tr>
                                            <td><?php echo $no++; ?></td>
                                              <?php 
                                            foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                    ?>
                                                        <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                    ?>
                                                        <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                            ?>
                                                  <td><?php echo $key['total']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 bg-danger">
                            <h6 class="m-0 font-weight-bold text-white">Itemset 3</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Produk 1</th>
                                            <th>Produk 2</th>
                                            <th>Produk 3</th>
                                            <th>Transaksi</th>
                                            <th>Support</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($data['item3_hasil'] as $key ) {?>
                                         <tr>
                                            <td><?php echo $no++; ?></td>
                                           <?php 
                                            foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                    ?>
                                                        <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                    ?>
                                                        <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_3']){
                                                    ?>
                                                        <td><?php echo $keys['nama']; ?></td>
                                                    <?php
                                                    }
                                                }
                                            ?>
                                                <td><?php echo $key['total']; ?></td>
                                                <td><?php echo $key['jumlah']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <div class="alert alert-danger" role="alert">
                                Itemset 3 kurang dari nilai support. Maka itemset 3 tidak termasuk.
                            </div>
                            <span class="badge rounded-pill text-bg-danger"></span>

                        </div>
                    </div>
                    <!-- //assosiasi -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Pola Asosiasi</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Rule</th>
                                            <th>A&B</th>
                                            <th>A</th>
                                            <th>Confidence</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($data['asso_item2'] as $key ) {?>
                                        <?php 
                                            foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                        $nama1 = $keys['nama'];
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                        $nama2 = $keys['nama'];
                                                    }
                                                }
                                            ?>
                                                <tr>
                                                    <td>Jika membeli <b><?php echo $nama1; ?></b> maka membeli <b><?php echo $nama2; ?></b></td>
                                                    <td><?php echo $key['AB']; ?></td>
                                                    <td><?php echo $key['A']; ?></td>
                                                    <td><?php echo $key['cofidence']; ?></td>
                                                </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <h5 class="text-success"><b>Asosiasi Final</b></h5>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Rule</th>
                                            <th>Support</th>
                                            <th>Confidence</th>
                                            <th>Support x Cofidence</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no=1;
                                        foreach ($data['asso_item2_berhasil'] as $key ) {?>
                                          <?php 
                                            foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                        $nama1 = $keys['nama'];
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                        $nama2 = $keys['nama'];
                                                    }
                                                }
                                            ?>
                                         <tr>
                                                <td>Jika membeli <b><?php echo $nama1; ?></b> maka membeli <b><?php echo $nama2; ?></b></td>
                                                <td><?php echo $key['support']; ?></td>
                                                <td><?php echo $key['cofidence']; ?></td>
                                                <td><?php echo $key['total']; ?></td>
                                        </tr>
                                        <?php
                                        } 
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Hasil</h6>
                        </div>
                        <div class="card-body">
                            <h5>Aturan Asosiasi</h5>
                           
                             <?php 
                                foreach ($produk as $keys) {
                                        if($keys['id_produk'] == $assoMax[0]['id_produk_1']){
                                            $nama1 = $keys['nama'];
                                        }
                                    }
                                    foreach ($produk as $keys) {
                                        if($keys['id_produk'] == $assoMax[0]['id_produk_2']){
                                            $nama2 = $keys['nama'];
                                        }
                                    }
                                ?>
                                 <h6>diambil dari support x confidence yang besar maka : </h6> <h4 class="text-danger">Jika membeli produk <b><?php echo $nama1; ?></b> maka membeli produk <b><?php echo $nama2; ?></b></h4>
                            
                        </div>
                    </div>
                    <!-- Tata letak barang -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Tata letak barang</h6>
                        </div>
                        <div class="card-body">
                             <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                     
                                          <?php
                                        $no=1;
                                        foreach ($data['asso_item2_berhasil'] as $key ) {?>
                                          <?php 
                                            foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_1']){
                                                        $nama1 = $keys['nama'];
                                                    }
                                                }
                                                foreach ($produk as $keys) {
                                                    if($keys['id_produk'] == $key['id_produk_2']){
                                                        $nama2 = $keys['nama'];
                                                    }
                                                }
                                                ?>
                                            <tr>
                                                <td>Taruh barang <b><?php echo $nama1 ?></b> di sebelah barang <b><?php echo $nama2 ?></b></td> 
                                            </tr>   
                                            <?php
                                            }
                                            ?>
                                      
                                    </thead>
                                </table>
                        </div>
                    </div>
                     </div>
                    <!-- Diskon -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Paket diskon <?php echo date('M', strtotime($bulan_awal)); ?></h6>
                        </div>
                        <div class="card-body">
                                        <?php
                                            foreach ($produk as $keys) {
                                            if($keys['id_produk'] == $assoMax[0]['id_produk_1']){
                                                $nama1 = $keys['nama'];
                                            }
                                            }
                                        foreach ($produk as $keys) {
                                            if($keys['id_produk'] == $assoMax[0]['id_produk_2']){
                                                $nama2 = $keys['nama'];
                                            }
                                        }
                                        ?>
                                     <h4><?php echo "Produk ".$nama1." & ".$nama2; ?></h4> 
                                  
                   
                        </div>
                    </div>
</div>

<?php $this->endSection(); ?>